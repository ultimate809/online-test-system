
public class mcqtest {

}
